# solve-issue.ps1 - Resuelve un issue específico usando OpenCode
# =================================================================

param(
    [Parameter(Mandatory = $true)]
    [int]$IssueNumber,

    [Parameter(Mandatory = $true)]
    [string]$IssueTitle,

    [Parameter(Mandatory = $false)]
    [string]$IssueBody = ""
)

# Cargar configuración
. "$PSScriptRoot\config.ps1"

function Solve-Issue {
    param(
        [int]$Number,
        [string]$Title,
        [string]$Body
    )

    try {
        Write-Log "Iniciando resolución del issue #${Number} - $Title"

        # Cambiar al directorio del repositorio
        Set-Location $script:RepoPath

        # Asegurar que estamos en el branch base actualizado
        Write-Log "Cambiando a branch $script:BaseBranch y actualizando..."
        git checkout $script:BaseBranch 2>&1 | Out-Null
        git pull $script:RemoteAlias $script:BaseBranch 2>&1 | Out-Null

        # Crear branch para el issue
        $branchName = "$script:BranchPrefix$Number"
        Write-Log "Creando branch: $branchName"

        # Verificar si el branch ya existe localmente
        $branchExists = git branch --list $branchName
        if ($branchExists) {
            Write-Log "Branch local $branchName ya existe, eliminándolo..." "WARN"
            git branch -D $branchName 2>&1 | Out-Null
        }

        # Eliminar branch remoto si existe
        $remoteBranchExists = git ls-remote --heads $script:RemoteAlias $branchName 2>&1
        if ($remoteBranchExists) {
            Write-Log "Branch remoto $branchName ya existe, eliminándolo..." "WARN"
            git push $script:RemoteAlias --delete $branchName 2>&1 | Out-Null
        }

        git checkout -b $branchName 2>&1 | Out-Null

        # Preparar el prompt para OpenCode - directo y específico
        $prompt = @"
TAREA: $Title

DESCRIPCIÓN:
$Body

INSTRUCCIONES:
- Edita los archivos necesarios para resolver esta tarea
- NO hagas commit ni push
- Aplica los cambios directamente en los archivos
"@

        Write-Log "Ejecutando OpenCode..."

        # Ejecutar OpenCode en modo no interactivo
        $opencodeOutput = opencode run $prompt 2>&1

        if ($LASTEXITCODE -ne 0) {
            Write-Log "Error al ejecutar OpenCode: $opencodeOutput" "ERROR"
            return $false
        }

        Write-Log "OpenCode completado exitosamente"

        # Verificar si hay cambios para commit
        $status = git status --porcelain
        if (-not $status) {
            Write-Log "No se detectaron cambios después de ejecutar OpenCode" "WARN"
            # Volver al branch base
            git checkout $script:BaseBranch 2>&1 | Out-Null
            git branch -D $branchName 2>&1 | Out-Null
            return $false
        }

        # Hacer commit de los cambios
        $commitMessage = "feat: resolve issue #${Number} - $Title"
        Write-Log "Haciendo commit: $commitMessage"

        # Añadir todos los cambios excepto archivos de configuración y scripts
        git add -A 2>&1 | Out-Null
        git reset HEAD -- .claude/ scripts/ .opencode/ 2>&1 | Out-Null

        # Verificar qué se va a commitear
        $stagedFiles = git diff --cached --name-only 2>&1
        Write-Log "Archivos staged: $stagedFiles"

        if (-not $stagedFiles) {
            Write-Log "No hay archivos para commitear después de excluir configs" "WARN"
            git checkout $script:BaseBranch 2>&1 | Out-Null
            git branch -D $branchName 2>&1 | Out-Null
            return $false
        }

        $commitOutput = git commit -m $commitMessage 2>&1
        Write-Log "Commit output: $commitOutput"

        if ($LASTEXITCODE -ne 0) {
            Write-Log "Error al hacer commit: $commitOutput" "ERROR"
            return $false
        }

        # Push del branch (force para sobrescribir si existe)
        Write-Log "Haciendo push a $script:RemoteAlias/$branchName..."
        $pushOutput = git push -u --force $script:RemoteAlias $branchName 2>&1
        Write-Log "Push output: $pushOutput"

        if ($LASTEXITCODE -ne 0) {
            Write-Log "Error al hacer push: $pushOutput" "ERROR"
            return $false
        }

        # Esperar a que GitHub sincronice
        Write-Log "Esperando sincronización con GitHub..."
        Start-Sleep -Seconds 3

        # Crear PR
        Write-Log "Creando Pull Request..."
        $prTitle = "feat: #${Number} $Title"
        $prBody = @"
## Resuelve Issue #${Number}

$Body

---
Closes #${Number}

> Este PR fue generado automáticamente por el Agente IA
"@

        # Guardar body en archivo temporal para evitar problemas con caracteres especiales
        $tempBodyFile = [System.IO.Path]::GetTempFileName()
        Set-Content -Path $tempBodyFile -Value $prBody -Encoding UTF8

        $prResult = gh pr create --title $prTitle --body-file $tempBodyFile --base $script:BaseBranch --head $branchName 2>&1

        Remove-Item -Path $tempBodyFile -Force -ErrorAction SilentlyContinue

        # Verificar si el PR existe (aunque gh pr create falle, puede haberse creado)
        $prUrl = gh pr view $branchName --json url --jq ".url" 2>&1

        if ($prUrl -match "github.com") {
            Write-Log "PR creado exitosamente: $prUrl"
        }
        elseif ($LASTEXITCODE -ne 0) {
            Write-Log "Error al crear PR: $prResult" "ERROR"
            return $false
        }
        else {
            Write-Log "PR creado: $prResult"
        }

        # Comentar en el issue
        $comment = @"
:robot: **Agente IA**

He creado un Pull Request para resolver este issue.

**Estado:** Pendiente de revisión humana

Por favor revisa los cambios y aprueba el PR si la solución es correcta.
"@

        gh issue comment $Number --body $comment 2>&1 | Out-Null

        # Actualizar labels del issue
        gh issue edit $Number `
            --remove-label $script:Labels.Processing `
            --add-label $script:Labels.Review 2>&1 | Out-Null

        Write-Log "Issue #${Number} procesado exitosamente"

        # Volver al branch base
        git checkout $script:BaseBranch 2>&1 | Out-Null

        return $true
    }
    catch {
        Write-Log "Error procesando issue #${Number}: $_" "ERROR"

        # Intentar volver al branch base en caso de error
        try {
            git checkout $script:BaseBranch 2>&1 | Out-Null
        }
        catch { }

        return $false
    }
}

# Ejecutar
$result = Solve-Issue -Number $IssueNumber -Title $IssueTitle -Body $IssueBody
exit $(if ($result) { 0 } else { 1 })
